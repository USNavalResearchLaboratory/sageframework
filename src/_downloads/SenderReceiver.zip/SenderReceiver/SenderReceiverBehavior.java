/*  Use the following command line to build:
		javac -cp "%SAGE_SERVER_HOME%"\SageJavaBehaviorInterface.jar SenderReceiverBehavior.java

	 Create JAR file:
	 	jar cf SenderReceiverBehavior.jar SenderReceiverBehavior.class
*/

import nrl.sage.BehaviorInterface.*;

public class SenderReceiverBehavior extends SageBehavior
{
	int count;
	String senderAgent;
	String senderNode;
	String receiptAgent;
	String receiptNode;

	public SenderReceiverBehavior()
	{
		m_name = "SenderReceiverBehavior";
		m_description = "Periodically sends messages to other agents all while receiving messages";
		m_executionType = ExecutionType.TimedCyclical;
		m_delay = 50;
		m_period = 200;
	}
	
	public boolean setUp(Result result)
	{
		count = 1;
		result.m_executionResult = ExecutionResultType.NotSet;
		return true;
	}
	
	public boolean action(Result result)
	{
		try{
			// Using Agent state, retrieve the information of the Agent using this Behavior
			senderAgent = (String)getState("agent");
			senderNode = (String)getState("node");

			// Knowing who the sender agent is, store the intended agent recipient information
			if (senderAgent.equals("Agent1")){
				receiptAgent = "Agent2";
				receiptNode = "NodeTwo";
			}
			else {
				receiptAgent = "Agent1";
				receiptNode = "NodeOne";
			}

			// Construct the message content to send.
			Message messageToAgent = new Message();
			messageToAgent.m_message = "send" + " messageNo:" +Integer.toString(count);
			messageToAgent.m_data.add(senderAgent);
			messageToAgent.m_data.add(receiptAgent);
			messageToAgent.m_targetNodeName = receiptNode;
			messageToAgent.m_targetAgentName = receiptAgent;
			messageToAgent.m_topic = "talking";
			sendMessage(messageToAgent);
			
			// Increase count to know how many messages have been sent
			count++;

			System.out.println(senderAgent + " sent " + messageToAgent.m_message + " to " +receiptAgent);
		}
		catch (Exception e){
			result.m_exception = e.toString();
			result.m_executionResult = ExecutionResultType.ExceptionThrown;
		}
		
		result.m_executionResult = ExecutionResultType.NotSet;
		return true;
	}
	
	public boolean message(Message message, Result result)
	{
		// Print the message content in the console
		System.out.println(message.m_data.get(1) + " received " + message.m_message + " from " + message.m_data.get(0));
		
		// Deactivate agents after 20 messages have been sent
		if (count>20){
			setAgentActive(receiptNode, receiptAgent, false);
			setAgentActive(senderNode, senderAgent, false);
		}

		result.m_executionResult = ExecutionResultType.NotSet;
		return true;	
	}
	public boolean tearDown(Result result)
	{

		System.out.println("Tearing down behavior " + m_name);

		// Log event
		result.m_logMessages.add(senderAgent + " signing off. Goodbye!");

		// Report back to the Server indicating a successful teardown
		result.m_executionResult = ExecutionResultType.CompletionSuccess;
		return true;
	}

}